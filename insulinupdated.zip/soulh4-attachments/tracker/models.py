from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver

# Create your models here.

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    date_of_birth = models.DateField(null=True, blank=True)
    diabetes_type = models.CharField(max_length=50, null=True, blank=True)
    target_blood_sugar_min = models.IntegerField(null=True, blank=True)
    target_blood_sugar_max = models.IntegerField(null=True, blank=True)
    insulin_sensitivity = models.FloatField(null=True, blank=True)
    carb_ratio = models.FloatField(null=True, blank=True)

    def __str__(self):
        return f"{self.user.username}'s Profile"

class Reading(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    blood_sugar = models.IntegerField()
    insulin = models.FloatField()
    notes = models.TextField(blank=True)
    timestamp = models.DateTimeField(auto_now_add=True)
    carbs = models.IntegerField(null=True, blank=True)
    exercise = models.BooleanField(default=False)
    stress_level = models.IntegerField(choices=[(i, str(i)) for i in range(1, 6)], null=True, blank=True)

    def __str__(self):
        return f"{self.user.username}'s reading at {self.timestamp}"

@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    if created:
        UserProfile.objects.create(user=instance)

@receiver(post_save, sender=User)
def save_user_profile(sender, instance, **kwargs):
    instance.userprofile.save()
