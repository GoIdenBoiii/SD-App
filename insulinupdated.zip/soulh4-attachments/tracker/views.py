from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import Reading, UserProfile
from django.utils import timezone
from django.db.models import Q
from django.http import HttpResponse
import csv

@login_required
def home(request):
    recent_readings = Reading.objects.filter(user=request.user).order_by('-timestamp')[:5]
    return render(request, 'home.html', {'readings': recent_readings})

@login_required
def add_reading(request):
    if request.method == 'POST':
        blood_sugar = request.POST.get('blood_sugar')
        insulin = request.POST.get('insulin')
        notes = request.POST.get('notes')
        carbs = request.POST.get('carbs')
        exercise = request.POST.get('exercise') == 'on'
        stress_level = request.POST.get('stress_level')

        reading = Reading.objects.create(
            user=request.user,
            blood_sugar=blood_sugar,
            insulin=insulin,
            notes=notes,
            carbs=carbs,
            exercise=exercise,
            stress_level=stress_level
        )
        messages.success(request, 'Reading added successfully!')
        return redirect('home')
    return render(request, 'home.html')

@login_required
def logs(request):
    readings = Reading.objects.filter(user=request.user).order_by('-timestamp')
    return render(request, 'logs.html', {'readings': readings})

@login_required
def profile(request):
    user_profile = UserProfile.objects.get(user=request.user)
    if request.method == 'POST':
        user_profile.date_of_birth = request.POST.get('date_of_birth')
        user_profile.diabetes_type = request.POST.get('diabetes_type')
        user_profile.target_blood_sugar_min = request.POST.get('target_blood_sugar_min')
        user_profile.target_blood_sugar_max = request.POST.get('target_blood_sugar_max')
        user_profile.insulin_sensitivity = request.POST.get('insulin_sensitivity')
        user_profile.carb_ratio = request.POST.get('carb_ratio')
        user_profile.save()
        messages.success(request, 'Profile updated successfully!')
        return redirect('profile')
    return render(request, 'profile.html', {'profile': user_profile})

@login_required
def settings(request):
    if request.method == 'POST':
        # Handle settings updates
        messages.success(request, 'Settings updated successfully!')
        return redirect('settings')
    return render(request, 'settings.html')

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            messages.success(request, 'Logged in successfully!')
            return redirect('home')
        else:
            messages.error(request, 'Invalid username or password')
    return render(request, 'login.html')

def logout_view(request):
    logout(request)
    messages.success(request, 'Logged out successfully!')
    return redirect('login')

def signup(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, 'Account created successfully!')
            return redirect('home')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field}: {error}")
    else:
        form = UserCreationForm()
    return render(request, 'signup.html', {'form': form})

@login_required
def export_data(request):
    # Get all readings for the user
    readings = Reading.objects.filter(user=request.user).order_by('-timestamp')
    
    # Create the CSV response
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="insulin_tracker_data.csv"'
    
    writer = csv.writer(response)
    writer.writerow(['Date', 'Blood Sugar', 'Insulin', 'Carbs', 'Exercise', 'Stress Level', 'Notes'])
    
    for reading in readings:
        writer.writerow([
            reading.timestamp.strftime('%Y-%m-%d %H:%M:%S'),
            reading.blood_sugar,
            reading.insulin,
            reading.carbs,
            'Yes' if reading.exercise else 'No',
            reading.stress_level,
            reading.notes
        ])
    
    return response
