from django.contrib import admin
from .models import Reading, UserProfile

@admin.register(Reading)
class ReadingAdmin(admin.ModelAdmin):
    list_display = ('user', 'blood_sugar', 'insulin', 'timestamp')
    list_filter = ('user', 'timestamp')
    search_fields = ('user__username', 'notes')

@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'diabetes_type', 'target_blood_sugar_min', 'target_blood_sugar_max')
    list_filter = ('diabetes_type',)
    search_fields = ('user__username',)
