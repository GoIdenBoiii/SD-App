# Blood Sugar and Insulin Tracker

A web application to help people with diabetes track their blood sugar levels, insulin doses, and related health metrics.

## Features

- User authentication (signup, login, logout)
- Track blood sugar readings and insulin doses
- Record carbohydrate intake, exercise, and stress levels
- Personal profile management
- Data export functionality
- Customizable reminders
- Multi-language support

## Prerequisites

Before you begin, ensure you have the following installed on your computer:

1. Python (3.8 or higher)
   - Download from: https://www.python.org/downloads/
   - During installation, make sure to check "Add Python to PATH"

2. Git (optional, for cloning the repository)
   - Download from: https://git-scm.com/downloads

## Installation Steps

1. Clone or download this repository:
   ```bash
   git clone <repository-url>
   # OR download and extract the ZIP file
   ```

2. Open a terminal/command prompt and navigate to the project directory:
   ```bash
   cd path/to/insulin_tracker
   ```

3. Create a virtual environment:
   ```bash
   # On Windows
   python -m venv venv
   
   # On macOS/Linux
   python3 -m venv venv
   ```

4. Activate the virtual environment:
   ```bash
   # On Windows
   venv\Scripts\activate
   
   # On macOS/Linux
   source venv/bin/activate
   ```

5. Install required packages:
   ```bash
   pip install django
   ```

6. Set up the database:
   ```bash
   python manage.py migrate
   ```

7. Create a superuser (admin account):
   ```bash
   python manage.py createsuperuser
   # Follow the prompts to create username and password
   ```

## Running the Application

1. Make sure your virtual environment is activated (see step 4 above)

2. Start the development server:
   ```bash
   python manage.py runserver
   ```

3. Open your web browser and go to:
   - Main application: http://127.0.0.1:8000/
   - Admin interface: http://127.0.0.1:8000/admin/

## Using the Application

1. Create an account:
   - Click "Sign Up" on the home page
   - Fill in your username and password
   - Click "Sign Up" to create your account

2. Complete your profile:
   - After logging in, click your username or go to Profile
   - Fill in your personal details
   - Click "Update Profile" to save

3. Track your readings:
   - On the home page, use the form to add new readings
   - Enter your blood sugar level, insulin dose, and other details
   - Click "Add Reading" to save

4. View your history:
   - Click "Logs" to see all your past readings
   - Use filters to find specific entries

5. Customize settings:
   - Click "Settings" to access additional options
   - Set up reminders
   - Configure your preferred language
   - Export your data

## Troubleshooting

1. If you see "No such table" errors:
   ```bash
   python manage.py migrate
   ```

2. If you can't log in to the admin interface:
   ```bash
   python manage.py createsuperuser
   ```

3. If the server won't start:
   - Make sure no other application is using port 8000
   - Check that you're in the correct directory
   - Verify your virtual environment is activated

## Support

If you encounter any issues or need help:
1. Check the troubleshooting section above
2. Look for error messages in the terminal
3. Make sure all prerequisites are installed correctly

## Security Note

This is a development setup and not suitable for production use. For production:
- Change DEBUG to False in settings.py
- Set a secure SECRET_KEY
- Configure a production-grade database
- Set up proper static file serving
- Use HTTPS 