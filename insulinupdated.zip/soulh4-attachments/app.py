from flask import Flask, render_template, request, redirect, url_for, flash, session
import os
from datetime import datetime

app = Flask(__name__, template_folder='templates/templates')
app.secret_key = 'your_secret_key'  # Required for session and flash

# Mock data for demonstration
class Reading:
    def __init__(self, blood_sugar, insulin, notes, timestamp=None):
        self.blood_sugar = blood_sugar
        self.insulin = insulin
        self.notes = notes
        self.timestamp = timestamp or datetime.now()

mock_readings = [
    Reading(120, 5, "After breakfast", datetime.now()),
    Reading(140, 6, "After lunch", datetime.now()),
]

@app.route('/')
@app.route('/home')
def home():
    return render_template('home.html', readings=mock_readings)

@app.route('/add_reading', methods=['POST'])
def add_reading():
    if request.method == 'POST':
        blood_sugar = request.form.get('blood_sugar')
        insulin = request.form.get('insulin')
        notes = request.form.get('notes')
        
        # Add new reading to mock data
        mock_readings.insert(0, Reading(blood_sugar, insulin, notes))
        flash('Reading added successfully!')
        
    return redirect(url_for('home'))

@app.route('/logs')
def logs():
    return render_template('logs.html', readings=mock_readings)

@app.route('/profile')
def profile():
    return render_template('profile.html')

@app.route('/settings')
def settings():
    return render_template('settings.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        # Mock login
        username = request.form.get('username')
        password = request.form.get('password')
        if username and password:  # Simple validation
            session['user_id'] = 1  # Mock user ID
            flash('Logged in successfully!')
            return redirect(url_for('home'))
        else:
            flash('Invalid username or password')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    flash('Logged out successfully!')
    return redirect(url_for('login'))

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        # Mock signup
        username = request.form.get('username')
        password = request.form.get('password')
        if username and password:  # Simple validation
            session['user_id'] = 1  # Mock user ID
            flash('Account created successfully!')
            return redirect(url_for('home'))
        else:
            flash('Invalid username or password')
    return render_template('signup.html')

if __name__ == '__main__':
    app.run(debug=True) 